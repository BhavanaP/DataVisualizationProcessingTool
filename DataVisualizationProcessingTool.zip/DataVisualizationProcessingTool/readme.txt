unzip the file
Go to the extracted folder and run the pde file
load the images present in the data folder into the pde file if necessary
Find the screenshots in the screenshots folder
The processing file visualizes the schedule of falcons team
Here in my processing, after completing all the matches, the falcon team goes to the first location which is Florida
